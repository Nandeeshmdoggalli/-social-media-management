//submited serched name link
function serched_name_over1(uid)
{
	document.getElementById("Name_font1"+uid).style.textDecoration = "underline"
}

function serched_name_out1(uid)
{
	document.getElementById("Name_font1"+uid).style.textDecoration = "none"
}


