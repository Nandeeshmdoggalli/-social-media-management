<html>
<head>
</head>
<body>
	 <!--head background-->
	<div style="position:absolute;left:0%;top:0%; height:13.2%; width:100%; z-index:-1; background:#3e717d"></div>
	<!--text: faceback -->
	<div style="position:absolute;left:13.5%; top:3.3%; font-size:45; font-weight:900; color:#FFFFFF; font-weight:bold;"> <font face="myFbFont">  Socail Media </font> </div>
	<!--body background-->
	<div style="position:absolute;left:0%;top:13.2%; height:90%; width:100%; z-index:-1; background:#ffffff">   </div>
	<!--bottam background-->
	<div style="position:absolute;left:0%;top:110%; height:5%; width:100%; z-index:-1; background:#ffffff">   </div>
    <div style="position:absolute;left:5%;top:105%;"><font face="myFbFont"> Developer: <span style=" color:#3e717d;" id="my_name"> Suraksha & Swathi</span></font></div>
</body>
</html>
