CREATE 
    ALGORITHM = UNDEFINED 
    DEFINER = `root`@`localhost` 
    SQL SECURITY DEFINER
VIEW `socialmedia_dbms`.`full_posts_details` AS
    SELECT 
        `po`.`Post_ID` AS `Post_ID`,
        `po`.`Posted_User_ID` AS `Posted_User_ID`,
        (SELECT 
                `u`.`First_name`
            FROM
                `socialmedia_dbms`.`users` `u`
            WHERE
                (`u`.`User_ID` = `po`.`Posted_User_ID`)) AS `Posted_Users_name`,
        (SELECT 
                `u`.`AGE`
            FROM
                `socialmedia_dbms`.`users` `u`
            WHERE
                (`u`.`User_ID` = `po`.`Posted_User_ID`)) AS `Posted_Users_age`,
        `po`.`Post_Date` AS `Post_Date`,
        `po`.`Post_Content` AS `Post_Content`,
        (SELECT 
                COUNT(0)
            FROM
                `socialmedia_dbms`.`post_likes` `pl`
            WHERE
                (`pl`.`Post_ID` = `po`.`Post_ID`)) AS `numbet_of_likes`,
        (SELECT 
                COUNT(0)
            FROM
                `socialmedia_dbms`.`post_shares` `ps`
            WHERE
                (`ps`.`Post_ID` = `po`.`Post_ID`)) AS `numbet_of_shares`,
        (SELECT 
                COUNT(0)
            FROM
                `socialmedia_dbms`.`post_comments` `pc`
            WHERE
                (`pc`.`Post_ID` = `po`.`Post_ID`)) AS `numbet_of_comments`
    FROM
        `socialmedia_dbms`.`posts` `po`