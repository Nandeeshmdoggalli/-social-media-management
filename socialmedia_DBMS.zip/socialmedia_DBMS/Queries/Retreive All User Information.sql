SELECT 
        `u`.`User_ID` AS `User_ID`,
        `u`.`Email_ID` AS `Email_ID`,
        `u`.`First_name` AS `First_name`,
        `u`.`DOB` AS `DOB`,
        (SELECT 
                COUNT(0)
            FROM
                `socialmedia_dbms`.`friends` `fr`
            WHERE
                (`fr`.`User_ID` = `u`.`User_ID`)) AS `number_of_friends`,
        (SELECT 
                COUNT(0)
            FROM
                `socialmedia_dbms`.`page_likes` `pg`
            WHERE
                (`pg`.`Page_User_ID` = `u`.`User_ID`)) AS `number_of_pages`,
        (SELECT 
                COUNT(0)
            FROM
                `socialmedia_dbms`.`posts` `po`
            WHERE
                (`po`.`Posted_User_ID` = `u`.`User_ID`)) AS `number_of_posts`
    FROM
        `socialmedia_dbms`.`users` `u`